# NUMBERWORDS MODULE FOR DOLIBARR ERP/CRM

## 5.0

Support for multicurrency.


## 3.4.1

Compatibility wit Dolibarr 3.4.


## 1.0.0

Initial version